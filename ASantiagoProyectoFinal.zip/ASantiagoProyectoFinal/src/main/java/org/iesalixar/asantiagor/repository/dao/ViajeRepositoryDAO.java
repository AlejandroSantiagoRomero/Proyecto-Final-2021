package org.iesalixar.asantiagor.repository.dao;


import org.iesalixar.Asantiago.model.Viaje;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ViajeRepositoryDAO 
	extends JpaRepository<Viaje,Long>{

	

	Viaje findByName(String name);

}

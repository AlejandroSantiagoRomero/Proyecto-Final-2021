package org.iesalixar.asantiagor.repository;


import org.iesalixar.Asantiago.model.Soporte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SoporteRepository 
	extends JpaRepository<Soporte,Long>{

}

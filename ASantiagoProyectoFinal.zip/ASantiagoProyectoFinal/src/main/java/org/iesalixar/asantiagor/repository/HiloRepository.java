package org.iesalixar.asantiagor.repository;

import org.iesalixar.Asantiago.model.Hilo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HiloRepository 
	extends JpaRepository<Hilo,Long>{

	

	Hilo findByName(String name);

}

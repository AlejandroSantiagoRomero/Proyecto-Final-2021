package org.iesalixar.asantiagor.repository;

import org.iesalixar.Asantiago.model.Nave;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NaveRepository 
	extends JpaRepository<Nave,Long>{

	

	Nave findByName(String name);

}

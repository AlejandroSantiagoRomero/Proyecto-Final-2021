package org.iesalixar.asantiagor.repository.dao;


import org.iesalixar.Asantiago.model.Hilo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HiloRepositoryDAO 
	extends JpaRepository<Hilo,Long>{

	

	Hilo findByName(String name);

}

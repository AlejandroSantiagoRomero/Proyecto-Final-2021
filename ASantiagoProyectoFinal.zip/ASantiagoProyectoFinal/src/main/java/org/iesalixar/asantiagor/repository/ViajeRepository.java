package org.iesalixar.asantiagor.repository;

import org.iesalixar.Asantiago.model.Viaje;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ViajeRepository 
	extends JpaRepository<Viaje,Long>{

	

	Viaje findByName(String name);

}

package org.iesalixar.asantiagor.repository;

import org.iesalixar.Asantiago.model.Escala;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EscalaRepository 
	extends JpaRepository<Escala,Long>{

	

	Escala findByName(String name);

}

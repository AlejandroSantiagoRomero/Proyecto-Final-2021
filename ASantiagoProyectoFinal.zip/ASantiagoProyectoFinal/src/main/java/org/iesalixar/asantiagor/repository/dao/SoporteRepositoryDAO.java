package org.iesalixar.asantiagor.repository.dao;


import org.iesalixar.Asantiago.model.Soporte;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SoporteRepositoryDAO 
	extends JpaRepository<Soporte,Long>{

}

package org.iesalixar.Asantiago.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "nave")
public class Nave implements Serializable{
	//Atributos
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private int id;
	
	@Column
	private String nombreNave;
	
	@Column
	private int capacidad;
	
	@Column
	private String descripcion;
	
	@ManyToMany(mappedBy = "viaje")
	private Set<Viaje> viajes;
	//Contructor

	public Nave(String nombreNave, int capacidad, String descripcion, Set<Viaje> viajes) {
		super();
		this.nombreNave = nombreNave;
		this.capacidad = capacidad;
		this.descripcion = descripcion;
		this.viajes = viajes;
	}
	public Nave() {
		// TODO Auto-generated constructor stub
	}
	//Metodos
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombreNave() {
		return nombreNave;
	}

	public void setNombreNave(String nombreNave) {
		this.nombreNave = nombreNave;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Set<Viaje> getViajes() {
		return viajes;
	}

	public void setViajes(Set<Viaje> viajes) {
		this.viajes = viajes;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + capacidad;
		result = prime * result + ((descripcion == null) ? 0 : descripcion.hashCode());
		result = prime * result + id;
		result = prime * result + ((nombreNave == null) ? 0 : nombreNave.hashCode());
		result = prime * result + ((viajes == null) ? 0 : viajes.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Nave other = (Nave) obj;
		if (capacidad != other.capacidad)
			return false;
		if (descripcion == null) {
			if (other.descripcion != null)
				return false;
		} else if (!descripcion.equals(other.descripcion))
			return false;
		if (id != other.id)
			return false;
		if (nombreNave == null) {
			if (other.nombreNave != null)
				return false;
		} else if (!nombreNave.equals(other.nombreNave))
			return false;
		if (viajes == null) {
			if (other.viajes != null)
				return false;
		} else if (!viajes.equals(other.viajes))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Nave [id=" + id + ", nombreNave=" + nombreNave + ", capacidad=" + capacidad + ", descripcion="
				+ descripcion + ", viajes=" + viajes + "]";
	}
	
}

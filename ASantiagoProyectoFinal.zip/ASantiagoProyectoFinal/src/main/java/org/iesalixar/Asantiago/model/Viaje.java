package org.iesalixar.Asantiago.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "viaje")
public class Viaje implements Serializable{
	//Atributos
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column
	private String tipo; //Normal o transbordo
	
	@Column
	private int numeroDeNaves; //numero de naves que se usaran en el viaje
	
	@Column
	private String fecha; //formato de la fecha dd/mm/aaaa
	
	@Column
	private String horaDeSalida; //hora a la que sale la nave del "anden"
	
	@Column
	private String Origen;
	
	@Column
	private String Destino;
	
	@Column
	private int Precio; //precio del viaje
	
	@Column
	private String CategoriaViaje; // 1-Estandar 2-Premiun 3-Deluxe
	
	
	@ManyToMany
	@JoinTable(
	  name = "viaje_escala", 
	  joinColumns = @JoinColumn(name = "viaje_id"), 
	  inverseJoinColumns = @JoinColumn(name = "escala_id"))
	private Set<Escala> escalas;
	
	@ManyToMany
	@JoinTable(
	  name = "viaje_nave", 
	  joinColumns = @JoinColumn(name = "viaje_id"), 
	  inverseJoinColumns = @JoinColumn(name = "nave_id"))
	private Set<Nave> naves;
	//Constructor

	public Viaje(Set<Escala> escalas, Set<Nave> naves) {
		super();
		this.escalas = escalas;
		this.naves = naves;
	}

	public Viaje(String tipo, int numeroDeNaves, String fecha, String horaDeSalida, String origen, String destino,
			int precio, String categoriaViaje, Set<Escala> escalas, Set<Nave> naves) {
		super();
		this.tipo = tipo;
		this.numeroDeNaves = numeroDeNaves;
		this.fecha = fecha;
		this.horaDeSalida = horaDeSalida;
		Origen = origen;
		Destino = destino;
		Precio = precio;
		CategoriaViaje = categoriaViaje;
		this.escalas = escalas;
		this.naves = naves;
	}
	public Viaje() {
		// TODO Auto-generated constructor stub
	}
	//Metodos
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getNumeroDeNaves() {
		return numeroDeNaves;
	}

	public void setNumeroDeNaves(int numeroDeNaves) {
		this.numeroDeNaves = numeroDeNaves;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getHoraDeSalida() {
		return horaDeSalida;
	}

	public void setHoraDeSalida(String horaDeSalida) {
		this.horaDeSalida = horaDeSalida;
	}

	public String getOrigen() {
		return Origen;
	}

	public void setOrigen(String origen) {
		Origen = origen;
	}

	public String getDestino() {
		return Destino;
	}

	public void setDestino(String destino) {
		Destino = destino;
	}

	public int getPrecio() {
		return Precio;
	}

	public void setPrecio(int precio) {
		Precio = precio;
	}

	public String getCategoriaViaje() {
		return CategoriaViaje;
	}

	public void setCategoriaViaje(String categoriaViaje) {
		CategoriaViaje = categoriaViaje;
	}

	public Set<Escala> getEscalas() {
		return escalas;
	}

	public void setEscalas(Set<Escala> escalas) {
		this.escalas = escalas;
	}

	public Set<Nave> getNaves() {
		return naves;
	}

	public void setNaves(Set<Nave> naves) {
		this.naves = naves;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((CategoriaViaje == null) ? 0 : CategoriaViaje.hashCode());
		result = prime * result + ((Destino == null) ? 0 : Destino.hashCode());
		result = prime * result + ((Origen == null) ? 0 : Origen.hashCode());
		result = prime * result + Precio;
		result = prime * result + ((escalas == null) ? 0 : escalas.hashCode());
		result = prime * result + ((fecha == null) ? 0 : fecha.hashCode());
		result = prime * result + ((horaDeSalida == null) ? 0 : horaDeSalida.hashCode());
		result = prime * result + id;
		result = prime * result + ((naves == null) ? 0 : naves.hashCode());
		result = prime * result + numeroDeNaves;
		result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Viaje other = (Viaje) obj;
		if (CategoriaViaje == null) {
			if (other.CategoriaViaje != null)
				return false;
		} else if (!CategoriaViaje.equals(other.CategoriaViaje))
			return false;
		if (Destino == null) {
			if (other.Destino != null)
				return false;
		} else if (!Destino.equals(other.Destino))
			return false;
		if (Origen == null) {
			if (other.Origen != null)
				return false;
		} else if (!Origen.equals(other.Origen))
			return false;
		if (Precio != other.Precio)
			return false;
		if (escalas == null) {
			if (other.escalas != null)
				return false;
		} else if (!escalas.equals(other.escalas))
			return false;
		if (fecha == null) {
			if (other.fecha != null)
				return false;
		} else if (!fecha.equals(other.fecha))
			return false;
		if (horaDeSalida == null) {
			if (other.horaDeSalida != null)
				return false;
		} else if (!horaDeSalida.equals(other.horaDeSalida))
			return false;
		if (id != other.id)
			return false;
		if (naves == null) {
			if (other.naves != null)
				return false;
		} else if (!naves.equals(other.naves))
			return false;
		if (numeroDeNaves != other.numeroDeNaves)
			return false;
		if (tipo == null) {
			if (other.tipo != null)
				return false;
		} else if (!tipo.equals(other.tipo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Viaje [id=" + id + ", tipo=" + tipo + ", numeroDeNaves=" + numeroDeNaves + ", fecha=" + fecha
				+ ", horaDeSalida=" + horaDeSalida + ", Origen=" + Origen + ", Destino=" + Destino + ", Precio="
				+ Precio + ", CategoriaViaje=" + CategoriaViaje + ", escalas=" + escalas + ", naves=" + naves + "]";
	}
}

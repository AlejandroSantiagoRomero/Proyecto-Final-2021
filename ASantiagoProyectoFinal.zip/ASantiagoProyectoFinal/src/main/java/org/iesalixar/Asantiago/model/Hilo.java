package org.iesalixar.Asantiago.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="hilo")
public class Hilo implements Serializable{
	//Atributos
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column
	private String contenido;
	
	@Column
	private String Estado; //estado del hilo 1-abierto o en revision 2-cerrado
	
	@ManyToOne   
	@JoinColumn(name="client_id",nullable=true)
	private Client client;
	
	
	@OneToOne(mappedBy = "soporte")
    private Soporte soporte;

	//Contructor
	public Hilo(String contenido, String estado, Client client, Soporte soporte) {
		super();
		this.contenido = contenido;
		Estado = estado;
		this.client = client;
		this.soporte = soporte;
	}
	public Hilo() {
		// TODO Auto-generated constructor stub
	}
	//Metodos
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContenido() {
		return contenido;
	}

	public void setContenido(String contenido) {
		this.contenido = contenido;
	}

	public String getEstado() {
		return Estado;
	}

	public void setEstado(String estado) {
		Estado = estado;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Soporte getSoporte() {
		return soporte;
	}

	public void setSoporte(Soporte soporte) {
		this.soporte = soporte;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Estado == null) ? 0 : Estado.hashCode());
		result = prime * result + ((client == null) ? 0 : client.hashCode());
		result = prime * result + ((contenido == null) ? 0 : contenido.hashCode());
		result = prime * result + id;
		result = prime * result + ((soporte == null) ? 0 : soporte.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hilo other = (Hilo) obj;
		if (Estado == null) {
			if (other.Estado != null)
				return false;
		} else if (!Estado.equals(other.Estado))
			return false;
		if (client == null) {
			if (other.client != null)
				return false;
		} else if (!client.equals(other.client))
			return false;
		if (contenido == null) {
			if (other.contenido != null)
				return false;
		} else if (!contenido.equals(other.contenido))
			return false;
		if (id != other.id)
			return false;
		if (soporte == null) {
			if (other.soporte != null)
				return false;
		} else if (!soporte.equals(other.soporte))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Hilo [id=" + id + ", contenido=" + contenido + ", Estado=" + Estado + ", client=" + client
				+ ", soporte=" + soporte + "]";
	}
	
}

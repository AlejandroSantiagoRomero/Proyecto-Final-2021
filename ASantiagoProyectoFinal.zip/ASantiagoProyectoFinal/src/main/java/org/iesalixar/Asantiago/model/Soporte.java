package org.iesalixar.Asantiago.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="soporte")
public class Soporte implements Serializable{
	//Atributos
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column
	private String username;
	
	@Column
	private int numeroHilosCerrados;
	
	@OneToMany(mappedBy = "soporte", fetch = FetchType.EAGER)
	private Set<Hilo> hilos = new HashSet<Hilo>(); //hilos respondidos
	//Contructor

	public Soporte(String username, int numeroHilosCerrados, Set<Hilo> hilos) {
		super();
		this.username = username;
		this.numeroHilosCerrados = numeroHilosCerrados;
		this.hilos = hilos;
	}
	public Soporte() {
		// TODO Auto-generated constructor stub
	}
	//Metodos
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getNumeroHilosCerrados() {
		return numeroHilosCerrados;
	}

	public void setNumeroHilosCerrados(int numeroHilosCerrados) {
		this.numeroHilosCerrados = numeroHilosCerrados;
	}

	public Set<Hilo> getHilos() {
		return hilos;
	}

	public void setHilos(Set<Hilo> hilos) {
		this.hilos = hilos;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hilos == null) ? 0 : hilos.hashCode());
		result = prime * result + id;
		result = prime * result + numeroHilosCerrados;
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Soporte other = (Soporte) obj;
		if (hilos == null) {
			if (other.hilos != null)
				return false;
		} else if (!hilos.equals(other.hilos))
			return false;
		if (id != other.id)
			return false;
		if (numeroHilosCerrados != other.numeroHilosCerrados)
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Soporte [id=" + id + ", username=" + username + ", numeroHilosCerrados=" + numeroHilosCerrados
				+ ", hilos=" + hilos + "]";
	}
	
}

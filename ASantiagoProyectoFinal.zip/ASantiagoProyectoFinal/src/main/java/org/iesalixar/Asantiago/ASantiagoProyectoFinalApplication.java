package org.iesalixar.Asantiago;

import java.util.HashSet;
import java.util.Set;

import org.iesalixar.Asantiago.model.*;
import org.iesalixar.asantiagor.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ASantiagoProyectoFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ASantiagoProyectoFinalApplication.class, args);
	}

	@Bean
	CommandLineRunner initData(
			AdministradorRepository administradorRepository,
			ClientRepository clientRepository,
			SoporteRepository soporteRepository,
			EscalaRepository escalaRepository,
			HiloRepository hiloRepository,
			NaveRepository naveRepository,
			ViajeRepository viajeRepository
			) {
		return (args) -> {
			
			Administrador admin1 = new Administrador();
			admin1.setUsername("admin1");
			
			Client client1 = new Client();
			client1.setNombre("Alex");
			client1.setApellido("Santiago");
			
			Soporte soporte1 = new Soporte();
			soporte1.setUsername("soporte1");
			soporte1.setNumeroHilosCerrados(0);
			
			Escala escala1 = new Escala();
			escala1.setNombre("Mercurio");
			escala1.setDescripcion("");
			
			Escala escala2 = new Escala();
			escala2.setNombre("Venus");
			escala2.setDescripcion("");
			
			Escala escala3 = new Escala();
			escala3.setNombre("Tierra");
			escala3.setDescripcion("");
			
			Escala escala4 = new Escala();
			escala4.setNombre("Marte");
			escala4.setDescripcion("");
			
			Escala escala5 = new Escala();
			escala5.setNombre("Jupiter");
			escala5.setDescripcion("");
			
			Escala escala6 = new Escala();
			escala6.setNombre("Saturno");
			escala6.setDescripcion("");
			
			Escala escala7 = new Escala();
			escala7.setNombre("Urano");
			escala7.setDescripcion("");
			
			Escala escala8 = new Escala();
			escala8.setNombre("Neptuno");
			escala8.setDescripcion("");
			
			Escala escala9 = new Escala();
			escala9.setNombre("Pluton");
			escala9.setDescripcion("");
			
			Nave nave1 = new Nave();
			nave1.setNombreNave("Enterprise");
			nave1.setCapacidad(250);
			nave1.setDescripcion("");
			
			
			Viaje viaje1 = new Viaje();
			viaje1.setOrigen("Mercurio");
			viaje1.setDestino("Marte");
			viaje1.setFecha("12/05/2021");
			viaje1.setHoraDeSalida("12:00");
			viaje1.setNumeroDeNaves(1);
			viaje1.setCategoriaViaje("Estandar");
			viaje1.setPrecio(10000);
			viaje1.setTipo("Normal");
			
			Hilo hilo1 = new Hilo();
			hilo1.setContenido("¿Si hay retraso en el vuelo habria reintegro de algun tipo?");
			hilo1.setEstado("abierto");
			hilo1.setSoporte(soporte1);
			
			Set<Hilo> list1_hilo = new HashSet<Hilo>();
			list1_hilo.add(hilo1);
			
			client1.setHilos(list1_hilo);
			
			Set<Client> list1_client = new HashSet<Client>();
			list1_client.add(client1);
			
			soporte1.setHilos(list1_hilo);
			
			Set<Viaje> list1_viaje = new HashSet<Viaje>();
			list1_viaje.add(viaje1);
			
			nave1.setViajes(list1_viaje);
			
			Set<Nave> list1_nave = new HashSet<Nave>();
			list1_nave.add(nave1);
			
			escala1.setViajes(list1_viaje);
			
			Set<Escala> list1_escala = new HashSet<Escala>();
			list1_escala.add(escala1);
			
			viaje1.setNaves(list1_nave);
			
			viaje1.setEscalas(list1_escala);
			
			administradorRepository.save(admin1);
			
			clientRepository.save(client1);
			
			soporteRepository.save(soporte1);
			
			escalaRepository.save(escala1);
			escalaRepository.save(escala2);
			escalaRepository.save(escala3);
			escalaRepository.save(escala4);
			escalaRepository.save(escala5);
			escalaRepository.save(escala6);
			escalaRepository.save(escala7);
			escalaRepository.save(escala8);
			escalaRepository.save(escala9);
			
			hiloRepository.save(hilo1);
			
			naveRepository.save(nave1);
			viajeRepository.save(viaje1);
			
		};
	}
}
